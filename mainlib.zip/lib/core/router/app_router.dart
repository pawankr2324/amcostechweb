// File: lib/core/router/app_router.dart

import 'package:amcostechweb/core/auth/screens/user_profile_screen.dart';

import 'package:go_router/go_router.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'package:amcostechweb/core/router/auth_wrapper.dart';
import 'package:amcostechweb/core/auth/screens/otp_screen.dart';
import 'package:amcostechweb/core/pages/home_page.dart';

import 'package:authentication/logic/user_cubit/user_cubit.dart';
import 'package:authentication/logic/user_cubit/user_state.dart';

/// Centralized route names
abstract class Routes {
  /// Root: shows AuthWrapper (decides between PhoneAuthScreen or HomePage)
  static const String root = '/';

  /// OTP verification screen (we will pass the verificationId via `extra`)
  static const String otp = '/otp';

  /// Main home/dashboard screen
  static const String home = '/home';

  /// User profile screen
  static const String profile = '/profile';
}

class AppRouter {
  static final GoRouter router = GoRouter(
    initialLocation: Routes.root,
    routes: <GoRoute>[
      /// 1. Root route → AuthWrapper
      GoRoute(
        path: Routes.root,
        name: 'Root',
        builder: (context, state) => const AuthWrapper(),
      ),

      /// 2. OTP route → OTPScreen
      ///
      ///    We expect that whoever calls `context.pushNamed(Routes.otp, extra: someString)`
      ///    passes a String as `extra`. Here, we extract it and hand it to OTPScreen.
      GoRoute(
        path: Routes.otp,
        name: 'OTP',
        builder: (context, state) {
          final extra = state.extra;
          if (extra is! String) {
            throw Exception(
              'OTP route requires a String verificationId in `extra`',
            );
          }
          // Pass that String into the OTPScreen constructor (see note below).
          return OTPScreen(verificationId: extra);
        },
      ),

      /// 3. Home route → HomePage
      GoRoute(
        path: Routes.home,
        name: 'Home',
        builder: (context, state) => const HomePage(),
      ),

      /// 4. Profile route → UserProfileScreen
      GoRoute(
        path: Routes.profile,
        name: 'Profile',
        builder: (context, state) => const UserProfileScreen(),
      ),
    ],

    /// REDIRECT LOGIC: guard /home and /profile if not logged in,
    /// and prevent an already‐logged‐in user from landing on `/` again.
    redirect: (context, state) {
      final userState = context.read<UserCubit>().state;
      final isLoggedIn = userState is UserLoaded;

      // Instead of state.location, use state.uri.path to get the path part
      final currentPath = state.uri.path;

      final goingToOtp = currentPath == Routes.otp;
      final goingToHome = currentPath == Routes.home;
      final goingToProfile = currentPath == Routes.profile;
      final atRoot = currentPath == Routes.root;

      // 1. If not logged in and trying to access /home or /profile → send to '/'
      if (!isLoggedIn && (goingToHome || goingToProfile)) {
        return Routes.root;
      }

      // 2. If already logged in and landing on '/', send to '/home'
      if (isLoggedIn && atRoot) {
        return Routes.home;
      }

      // 3. If already logged in and attempting /otp, redirect to /home
      if (isLoggedIn && goingToOtp) {
        return Routes.home;
      }

      // Otherwise, no redirection:
      return null;
    },
  );
}
