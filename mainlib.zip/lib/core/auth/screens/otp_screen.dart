import 'package:amcostechweb/core/router/app_router.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:authentication/logic/auth_cubit/phone_auth_cubit.dart';
import 'package:authentication/logic/auth_cubit/phone_auth_state.dart';
import 'package:amcostechweb/core/auth/widgets/otp_card.dart';
import 'package:amcostechweb/core/utils/responsive/responsive_layout.dart';
import 'package:go_router/go_router.dart';

/// We now require that a `verificationId` be passed in when constructing OTPScreen.
class OTPScreen extends StatelessWidget {
  final String verificationId;

  const OTPScreen({super.key, required this.verificationId});

  @override
  Widget build(BuildContext context) {
    final smsController = TextEditingController();

    Widget content = BlocListener<PhoneAuthCubit, PhoneAuthState>(
      listener: (context, state) {
        if (state is PhoneAuthSuccess) {
          // Once successful, navigate to '/home'
          context.go(Routes.home);
        } else if (state is PhoneAuthFailure) {
          ScaffoldMessenger.of(
            context,
          ).showSnackBar(SnackBar(content: Text(state.message)));
        }
      },
      child: OTPCard(
        smsController: smsController,
        verificationId: verificationId,
      ),
    );

    return Scaffold(
      body: ResponsiveLayout(
        mobile: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 48),
          child: content,
        ),
        tablet: Center(
          child: SizedBox(
            width: 400,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 32),
              child: content,
            ),
          ),
        ),
        desktop: Center(
          child: SizedBox(
            width: 600,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 48),
              child: content,
            ),
          ),
        ),
      ),
    );
  }
}
